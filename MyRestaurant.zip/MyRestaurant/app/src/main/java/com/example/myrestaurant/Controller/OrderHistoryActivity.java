package com.example.myrestaurant.Controller;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by User on 2017/12/2.
 */

public class OrderHistoryActivity extends AppCompatActivity {
}
