package com.example.myrestaurant.Model;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.Menu;

import com.example.myrestaurant.Controller.MenuActivity;

import java.util.ArrayList;

public class Order implements Parcelable {
    private String status;
    private double orderPlacedTime;
    private String userName;
    private ArrayList<Integer>  orderItemQuantity;
    private double orderTotal;

//    public enum OrderStatus{
//        Submitted("Submitted"),
//        NotAvailable("Not Available"),
//        PartiallyAvailable("Partially Available"),
//        Preparing("Preparing"),
//        Packaging("Packaging"),
//        FoodReady("Food Ready");
//
//        private String value;
//        private OrderStatus(String value){
//            this.value = value;
//        }
//
//        public String getValue() {
//            return value;
//        }
//
//        @Override
//        public String toString() {
//            return value;
//        }
//    }
public Order( ArrayList<Integer> orderItemQuantity) {
    this.orderItemQuantity = orderItemQuantity;
}
public Order()
{}

//    protected Order(Parcel in) {
//        status=in.readString();
//        orderPlacedTime = in.readDouble();
//        userName = in.readString();
//        orderTotal = in.readDouble();
//        orderItemQuantity = in.readArrayList(null);
//
//    }

    public static final Creator<Order> CREATOR = new Creator<Order>() {
        @Override
        public Order createFromParcel(Parcel in) {
            Order order=new Order();
            order.setStatus(in.readString());
            order.setOrderPlacedTime(in.readDouble());
            order.setUserName(in.readString());
            order.setOrderItemQuantity(in.readArrayList(null));
            order.setOrderTotal(in.readDouble());
            return order;
        }

        @Override
        public Order[] newArray(int size) {
            return new Order[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(status);
        parcel.writeDouble(orderPlacedTime);
        parcel.writeString(userName);
        parcel.writeList(orderItemQuantity);
        parcel.writeDouble(orderTotal);

    }

    public String getActionTodo() {
        return status;
    }

    public void setActionTodo(String actionTodo) {
        this.status = actionTodo;
    }

    public double getOrderPlacedTime() {
        return orderPlacedTime;
    }

    public void setOrderPlacedTime(double orderPlacedTime) {
        this.orderPlacedTime = orderPlacedTime;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public ArrayList<Integer> getOrderItemQuantity() {
        return orderItemQuantity;
    }

    public void setOrderItemQuantity(ArrayList<Integer> orderItemQuantity) {
        this.orderItemQuantity = orderItemQuantity;
    }

    public double getOrderTotal() {
        calculateOrderTotal();
        return orderTotal;
    }
public double calculateOrderTotal()
{
    orderTotal=orderItemQuantity.get(0)* MenuActivity.price_1+orderItemQuantity.get(1)* MenuActivity.price_2
            +orderItemQuantity.get(2)* MenuActivity.price_3+orderItemQuantity.get(3)* MenuActivity.price_4;
return orderTotal;
}
private void calculatime()
{

}
    public String getStatus() {
        return status;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}